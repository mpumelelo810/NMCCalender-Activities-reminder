# Youth Activities Calendar (Cloudflare Workers + D1)

Public read-only calendar, one administrator, three 07:00 SAST reminder jobs. Plain JavaScript, no runtime dependencies.

## Set up (needs your Cloudflare account and internet)
1. `npm install`, then `npx wrangler login`
2. `npx wrangler d1 create youth-calendar` and paste the `database_id` into `wrangler.toml`
3. `npx wrangler d1 migrations apply youth-calendar --remote`
4. Create the administrator (password is never stored in code):
   `ADMIN_PASSWORD='a long passphrase' node scripts/make-admin.mjs you@example.com` then run the printed SQL with
   `npx wrangler d1 execute youth-calendar --remote --command "<statement>"`
5. `npx wrangler deploy`, open the URL, then `/#admin` to sign in.
6. Tests: `npm test` (Node 20+). Local run: `npx wrangler d1 migrations apply youth-calendar --local` then `npm run dev`.

## Schedule
One cron, `0 5 * * *` UTC = 07:00 SAST (UTC+2, no daylight saving). Each run computes the SAST date and creates: a daily message (today and tomorrow, skipped if empty), the Monday preview (the Saturday of that week, sent even when empty), and the meeting agenda (published, not cancelled events of type Meeting today). `notification_runs` has UNIQUE(job, report_date), so reruns never duplicate.

## Notifications
`src/notify.js` is the only delivery point. With `NOTIFY_PROVIDER=none` messages are saved with status `generated` (visible in the admin page) and nothing is sent. No provider has been chosen or tested: pick one, verify its current free limits, add it to `notify.js`, and return `sent` only on its confirmed success. Failed deliveries are recorded as `failed` and are not retried automatically.

## Security notes
PBKDF2-SHA256 (100,000 iterations) password hashing; random session token, only its SHA-256 stored; HttpOnly/Secure/SameSite=Strict cookie; JSON-only same-origin writes; parameterised SQL; every `/api/admin/*` route checks the session. Add a Cloudflare rate-limiting rule on `/api/login` (not built in).

## Backup and restore (not automated, not yet tested)
- Export: `npx wrangler d1 export youth-calendar --remote --output backup-YYYY-MM-DD.sql`. Keep files private (not in Git); store them in a private drive.
- Point-in-time: D1 Time Travel (`npx wrangler d1 time-travel info youth-calendar`); check current retention for your plan.
- Restore only by the account owner via the CLI, never via a public route. Rehearse first: create `youth-calendar-test`, run `npx wrangler d1 execute youth-calendar-test --remote --file backup.sql`, check the row counts, then repeat on production only after exporting a fresh backup.

## Costs
Workers, D1 and Cron Triggers have free tiers with daily and storage limits that change; check Cloudflare's current pricing page. Charges could start if you exceed them or add a paid mail provider.
