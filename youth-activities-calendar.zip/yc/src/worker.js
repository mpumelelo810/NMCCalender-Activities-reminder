import { validateEvent, sastDate, addDays, upcomingSaturday, buildMessages, verifyPassword } from './lib.js';
import { deliver } from './notify.js';
const now = () => new Date().toISOString();
const json = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { 'content-type': 'application/json', 'cache-control': 'no-store', ...h } });
const hex = async s => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map(b => b.toString(16).padStart(2, '0')).join('');
const cookie = (req, n) => (req.headers.get('cookie') || '').split(/;\s*/).map(c => c.split('=')).find(c => c[0] === n)?.[1];
async function admin(req, env) {
  const t = cookie(req, 'sid'); if (!t) return null;
  return env.DB.prepare('SELECT admin_id FROM sessions WHERE token_hash=? AND expires_at>?').bind(await hex(t), now()).first();
}
async function audit(env, a, action, target) { await env.DB.prepare('INSERT INTO audit(admin_id,action,target,at) VALUES(?,?,?,?)').bind(a, action, target, now()).run(); }
async function api(req, env, url) {
  const p = url.pathname, m = req.method;
  if (p === '/api/events' && m === 'GET') {
    const from = /^\d{4}-\d{2}-\d{2}$/.test(url.searchParams.get('from') || '') ? url.searchParams.get('from') : sastDate(new Date());
    const { results } = await env.DB.prepare('SELECT id,title,date,start_time,end_time,location,description,category FROM events WHERE published=1 AND cancelled=0 AND date>=? ORDER BY date,start_time LIMIT 200').bind(from).all();
    return json(results, 200, { 'cache-control': 'public, max-age=60' });
  }
  if (m !== 'GET') { // writes: JSON only and same-origin (cookie is also SameSite=Strict)
    if (!(req.headers.get('content-type') || '').includes('application/json')) return json({ error: 'JSON required' }, 415);
    const o = req.headers.get('origin'); if (o && o !== url.origin) return json({ error: 'Forbidden' }, 403);
  }
  if (p === '/api/login' && m === 'POST') {
    const b = await req.json().catch(() => ({})), a = await env.DB.prepare('SELECT * FROM admins WHERE email=?').bind(String(b.email || '').toLowerCase()).first();
    if (!a || !(await verifyPassword(String(b.password || ''), a.password_hash))) return json({ error: 'Wrong email or password.' }, 401);
    const t = [...crypto.getRandomValues(new Uint8Array(32))].map(x => x.toString(16).padStart(2, '0')).join('');
    await env.DB.prepare('INSERT INTO sessions VALUES(?,?,?)').bind(await hex(t), a.id, new Date(Date.now() + 12 * 3600000).toISOString()).run();
    return json({ ok: true }, 200, { 'set-cookie': `sid=${t}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=43200` });
  }
  const who = await admin(req, env); if (!who) return json({ error: 'Sign in required.' }, 401);
  if (p === '/api/logout' && m === 'POST') { await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await hex(cookie(req, 'sid'))).run(); return json({ ok: true }, 200, { 'set-cookie': 'sid=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Strict' }); }
  if (p === '/api/admin/events' && m === 'GET') return json((await env.DB.prepare('SELECT * FROM events ORDER BY date DESC,start_time LIMIT 500').all()).results);
  if (p === '/api/admin/runs' && m === 'GET') return json((await env.DB.prepare('SELECT id,job,report_date,subject,body,status,detail,created_at FROM notification_runs ORDER BY id DESC LIMIT 50').all()).results);
  if (p === '/api/admin/events' && m === 'POST') {
    const v = validateEvent(await req.json().catch(() => ({}))); if (!v.ok) return json({ errors: v.errors }, 400);
    const id = crypto.randomUUID(), e = v.value;
    await env.DB.prepare('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').bind(id, e.title, e.date, e.start_time, e.end_time, e.location, e.description, e.category, e.published, e.cancelled, now(), now()).run();
    return json({ id }, 201);
  }
  const x = p.match(/^\/api\/admin\/events\/([0-9a-f-]{36})$/);
  if (x && m === 'PUT') {
    const v = validateEvent(await req.json().catch(() => ({}))); if (!v.ok) return json({ errors: v.errors }, 400); const e = v.value;
    const r = await env.DB.prepare('UPDATE events SET title=?,date=?,start_time=?,end_time=?,location=?,description=?,category=?,published=?,cancelled=?,updated_at=? WHERE id=?').bind(e.title, e.date, e.start_time, e.end_time, e.location, e.description, e.category, e.published, e.cancelled, now(), x[1]).run();
    return r.meta.changes ? json({ ok: true }) : json({ error: 'Not found' }, 404);
  }
  if (x && m === 'DELETE') {
    if ((await req.json().catch(() => ({}))).confirm !== x[1]) return json({ error: 'Send {"confirm": "<event id>"} to delete.' }, 400);
    const r = await env.DB.prepare('DELETE FROM events WHERE id=?').bind(x[1]).run(); await audit(env, who.admin_id, 'delete_event', x[1]);
    return r.meta.changes ? json({ ok: true }) : json({ error: 'Not found' }, 404);
  }
  return json({ error: 'Not found' }, 404);
}
export async function runJobs(env, when) {
  const today = sastDate(when), { results } = await env.DB.prepare('SELECT * FROM events WHERE date IN (?,?,?)').bind(today, addDays(today, 1), upcomingSaturday(today)).all();
  for (const msg of buildMessages(today, results)) {
    const ins = await env.DB.prepare("INSERT OR IGNORE INTO notification_runs(job,report_date,subject,body,status,created_at) VALUES(?,?,?,?,'generated',?)").bind(msg.job, msg.report_date, msg.subject, msg.body, now()).run();
    if (!ins.meta.changes) continue; // already processed for this job and date
    let r; try { r = await deliver(env, msg); } catch (err) { r = { status: 'failed', detail: String(err.message || err).slice(0, 300) }; }
    await env.DB.prepare('UPDATE notification_runs SET status=?,detail=? WHERE job=? AND report_date=?').bind(r.status, r.detail, msg.job, msg.report_date).run();
  }
}
export default {
  async fetch(req, env) { const url = new URL(req.url); try { return url.pathname.startsWith('/api/') ? await api(req, env, url) : env.ASSETS.fetch(req); } catch (e) { console.error(e); return json({ error: 'Something went wrong.' }, 500); } },
  async scheduled(ev, env, ctx) { ctx.waitUntil(runJobs(env, new Date(ev.scheduledTime))); }
};
