// Delivery adapter. Returns {status, detail}. 'generated' means content was produced but NOT sent.
// To add real delivery, add a provider here and set NOTIFY_PROVIDER; only return 'sent' when the provider confirms.
export async function deliver(env, msg) {
  if (!env.NOTIFY_PROVIDER || env.NOTIFY_PROVIDER === 'none') return { status: 'generated', detail: 'No delivery provider configured; message not sent.' };
  return { status: 'failed', detail: `Unknown provider "${env.NOTIFY_PROVIDER}".` };
}
